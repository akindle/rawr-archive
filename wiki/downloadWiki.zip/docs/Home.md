# Rawr

Rawr is a program for comparing and exploring gear for Bears, Cats, Moonkin, Healadins, Retadins, Mages, DPS Warriors, Protection Warriors, Trees, Hunters, Protection Paladins, Healing Priests, Shadow Priests, Enhancement Shamans, Warlocks, Rogues, Restoration Shamans, Elementals, and DPS & Tank Death Knights, in the MMORPG, World of Warcraft. Rawr has been designed from the start to be fun to use, and helpful in finding better combinations of gear, and what gear to obtain.

# Rawr Addon
We now have a Rawr Official Addon for in-game exporting and importing of character data. The addon is hosted on Curse. The Addon does not perform calculations like Rawr, it simply shows your exported Rawr data in wow tooltips and lets you export your character to Rawr (including bag and bank items) like Character Profiler used to.
[http://wow.curse.com/downloads/wow-addons/details/rawr-official.aspx](http://wow.curse.com/downloads/wow-addons/details/rawr-official.aspx)

## Tour of Rawr
<{ {video:url=http://www.youtube.com/watch?v=OjRM5SUoOoQ,type=youtube} }<
,,_Or in French: [http://www.youtube.com/watch?v=1p48SUFiq1M](http://www.youtube.com/watch?v=1p48SUFiq1M) (thanks to **KuroiSerenity**)_,,
,,_Or in German: [http://www.youtube.com/watch?v=WU6xGkmV7v4](http://www.youtube.com/watch?v=WU6xGkmV7v4) (thanks to **Lyrokk**)_,,

## Features
* Extremely user friendly, graphical, fast, easy to use interface.
* Automatically handles items. The ability to load your character from the Armory, automatically download info about items it doesn't know about, download info about possible upgrades, and download info about specific items you tell it to, ensure that you won't need to type in any item stats with Rawr. 
* The most comprehensive, and most accurate system for calculating your character stats, and ratings for individual items, based on your current gear, enchants, and buffs.

See the [Models](Models) page for a list of models and their status.

## Seeking Model Devs
We are currently seeking experienced C# programmers who want to help out with Rawr models. Please read the [Development Applications](Development-Applications) page for more details.

## Help & Documentation
We're working on building a collection of documentation, to help new and experienced users alike, to get the most out of Rawr: [Rawr Documentation](Documentation). If you haven't found an answer to your question after looking through the documentation and [Troubleshooting Guide](Troubleshooting), read the [Posting Guidelines](PostingGuidelines) and then feel free to ask on our Discussion forum or post an issue in the Issue Tracker.

## Donations
We accept donations to help support Rawr and accelerate development on it, and its models.
[Click here to donate to Rawr](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=2451163)

Thank you for your support!

###### {Current Version: 5.4.2.0} {Beta Version: 5.4.2.0}