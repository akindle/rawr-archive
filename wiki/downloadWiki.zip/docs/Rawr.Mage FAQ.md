# Mage Frequently Asked Questions (FAQ)

The issues here are Mage-specific issues. Please refer to the [general FAQ](FAQ) for more program-wide support.

* [Why is Rawr valueing gear with mp5 and spirit very high after I made some changes to gear? ](#Regen)
* [Why do charts only show survivability and 0 dps? ](#TalentsMissing)

----

* **{anchor:Regen}Q: Why is Rawr valueing gear with mp5 and spirit very high after I made some changes to gear?**
	* A: First double check that you have your character setup correctly. This includes verifying that you have proper raid buffs selected and that your fight settings are reasonable. For example if you set a fight to 10 minutes it is very unlikely that you will be chaincasting 100% of the time so consider lowering the dps time setting. If all this is correct then what can sometimes happen is that you're in an edge situation where making a small change in gear would require a change in spell cycles. This by default is not considered, but in some edge cases you might need it. To change this go to Advanced Options and uncheck Incremental Optimizations. This comes with performance cost so consider it having checked for normal use unless you run into problems.

* **{anchor:TalentsMissing}Q: Why do charts only show survivability and 0 dps?**
	* A: The most likely cause for this is that you forgot to enter your talents. The model will only consider cycles based on your specialization and until you spend some talents it can't make that determination.