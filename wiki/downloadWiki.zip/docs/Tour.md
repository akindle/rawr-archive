# Tour of Rawr
Please see the new Tour of Rawr video at: [http://www.youtube.com/watch?v=OjRM5SUoOoQ](http://www.youtube.com/watch?v=OjRM5SUoOoQ)

{video:url=http://www.youtube.com/watch?v=OjRM5SUoOoQ,type=youtube}

## [Where To Start](WhereToStart)