# Frequently asked questions (FAQ)

For FAQs regarding specific models:
* [Mage](Rawr.Mage-FAQ)
* [ProtPaladin](Rawr.ProtPaladin-FAQ)
* [Retribution](Rawr.Retribution-FAQ)
* [TankDK](Rawr.TankDK#FAQ)

* [Where can I set the Stat Weights in Rawr?](#01)
* [Why isn't the Optimizer keeping my meta gem active?](#02)
* [Enforce Gem Requirements is active, so why isn't Rawr forcing the gems to match the socket colors?](#03)
* [Why does the Optimizer try and equip two of my weapon when I only have one?](#04)
* [Why does a Troll's Berserking and an Orc's Bloodfury not show up in the Buffs list?](#05)
* [Why does the Optimizer sometimes lower my DPS?](#06)
* [Why does the Optimizer sometimes just rearrange my Gems?](#07)
* [Why is my Crit value so low, compared to the in-game character panel?](#08)
* [Why does X talent/glyph not show any value in the comparison lists?](#09)
* [Why is it when I run the Optimizer I don't end up hit and/or expertise capped?](#10)
* [Why do higher tier items sometimes show less value than lower tier items?](#11)
* [Why aren't items with Resilience considered relevant?](#12)
* [Why are the stats wrong for my X level (sub-80) character when I load from Armory?](#13)
* [Why can't I select X weapon type?](#14)
* [Why can't I select X armor type?](#15)
* [Why isn't my Hunter doing any DPS in the charts?](#16)

----

* **{anchor:01}Q:  Where can I set the Stat Weights in Rawr?**
	* A:  Rawr absolutely, flat out, completely, in _no way_ uses Stat Weights (the idea of assigning a Stat a value and using that to score gear, Eg- STR = 1.2 so an item with 20 STR would be value 24).  Instead, each Stat is calculated into a modeling process that includes all of the class' abilities with respect to the character as a whole.  The gear comparison then becomes the total character change that item would provide.  DPS classes see DPS changes, Tanks see Survivability changes, and Healers see HPS changes.  This is what sets Rawr apart from most other modeling programs.

* **{anchor:02}Q:  Why isn't the Optimizer keeping my meta gem active?**
	* A:  You need to set Enforce Gem Requirements to be enabled.  See [Gemmings](Gemmings) for more details.

* **{anchor:03}Q:  Enforce Gem Requirements is active, so why isn't Rawr forcing the gems to match the socket colors?**
	* A:  Enforce Gem Requirements only does two things: ensure that the meta gem is activated, and ensure that any Unique or Unique-Equipped gems are, in fact, unique.  The gemmings recommended may or may not match the socket bonuses, irregardless of this option's state.  Rawr does not have any options to set to force socket bonuses to be activated, and instead recommends the best gemming possible, whether it's with the socket bonus, or ignoring it.  See [Gemmings](Gemmings) for more details.

* **{anchor:04}Q:  Why does the Optimizer try and equip two of my weapon when I only have one?**
	* A:  The item is not Unique, so the Optimizer assumes that you simply have access to the item, as it does not know how many of a given item you have.  To restrict the Optimizer to consider only one copy of a weapon, right-click the item, select Edit, and mark the item as Unique. This will prevent the Optimizer from putting the item in both MH and OH slots, as if you had two copies of the item. The same process can be used for rings and trinkets.

* **{anchor:05}Q:  Why does a Troll's Berserking and an Orc's Bloodfury not show up in the Buffs list?**
	* A:  Racial buffs are automatically added to the character stats, based on your race selection in the Character Definition area of the Stats pane.

* **{anchor:06}Q:  {anchor:00}Why does the Optimizer sometimes lower my DPS?**
	* A:  The Optimizer operates on a Random Seed method, which is why it works at all. Sometimes it can't use that random seed to find a set that is better than what you are currently wearing.  This is a known issue that we wish to hopefully find a solution for in the future.  In the meantime, you can help the Optimizer to find the optimal setup by following these steps:
		* Limit the number of potential items that you mark as available to the Optimizer.  As the number of pieces of gear / gems / enchants rise, the number of potential solutions (results) the Optimizer can create increases exponentially.  Periodically clean up your list of items that you know will perform as well as other options.
		* Increase the Optimizer thoroughness by moving the slider on the Optimizer window to the right.  While the Optimizer will take longer to run, it will be checking through more and more potential setups the higher the thoroughness is set.
		* Make absolutely sure that everything on your current character is marked as available to the Optimizer.  This includes gear, enchants, and gems.  This should be mostly covered by a check that is run when you start the Optimizer, though we are currently refining the warning dialogue to be more descriptive (to tell you exactly what you are currently wearing is not available to the Optimizer).

* **{anchor:07}Q:  Why does the Optimizer sometimes just rearrange my Gems?**
	* A:  In the more modern versions of Rawr, this issue should no longer exist.

* **{anchor:08}Q:  Why is my Crit value so low, compared to the in-game character panel?**
	* A:  Boss level relative to your own affects your actual chance to deal a critical strike.  Targets that are three levels higher than your own (83, or Boss level) exhibit a 4.8 crit depression / conversion, which affects both white and yellow damage.  Rawr calculates and displays your actual chance to crit, while the in-game character panel reflects your stats against a same-level target.

* **{anchor:09}Q:  Why does X talent/glyph not show any value in the comparison lists?**
	* A:  Many talents cannot be valued by DPS gain or by Survivability Gain.  It's also possible that you do not have the Situation setting where the Talent/Glyph would have value. For example, If you are never Stunned, then a Warrior's Iron Will wouldn't have a value.

* **{anchor:10}Q:  Why is it when I run the Optimizer I don't end up hit and/or expertise capped?**
	* A:  The optimizer, when run without any requirements, will attempt to find the highest possible total DPS. In many cases, this does not include being hit/expertise capped, either by a small amount, or sometimes even by a larger amount.  This is usually a correct recommendation in terms of optimizing you DPS / tanking performance.  However, sometimes one may need to ensure that an interrupt or a Taunt does not miss.  To ensure that an avoidance cap is enforced, add the '% Chance to be Missed <= 0' requirement before optimizing.  Similar parameters are available (model-dependent) for Dodged, Parried, and Avoided, the latter taking into account all types of target avoidance.

* **{anchor:11}Q:  Why do higher tier items sometimes show less value than lower tier items?**
	* A:  Set Bonuses can have a serious impact on DPS; getting that 2nd or 4th piece can mean more or less for your character in specific gear-sets.  It could impact your meta gem requirements, depending on your setup.

* **{anchor:12}Q:  Why aren't items with Resilience considered relevant?**
	* A:  Rawr is for PvE, not PvP.  Modeling for PvP settings is an exercise in futility, due to the wide range of fight settings, high mobility, the extreme variability of damage intake and damage output requirements, and the sheer number of potential targets that are presented in PvP situations.  Some models allow for comparison of PvP-sourced items, despite the wasted item budget, and some filter out those items with Resilience.  Check the Options panel for your particular model for more information.

* **{anchor:13}Q:  Why are the stats wrong for my X level (sub-85) character when I load from Armory?**
	* A:  Rawr is for end-game PvE, meaning you should be level 85. Rawr does not factor things for leveling as there is no point, you will replace the item in a couple of levels anyway and all your raiding gear will end up requiring level 80 to wear.

* **{anchor:14}Q:  Why can't I select X weapon type?**
	* A:  Some weapon types are pointless to factor in depending on your model.  For example, Fury Warriors and Enhance Shaman will never use staves, and Arms Warriors will never use one-handed weapons.  Rawr intentionally does not consider such futile, sub-optimal situations.

* **{anchor:15}Q:  Why can't I select X armor type?**
	* A:  Each model typically only shows those items that are specifically designed for use with a certain class, but limiting the armor shown to that of the highest armor class that is wearable.  However,  there are certainly a number of situations in which downarmoring provides similar, only slightly lower, or sometimes even better performance for a given character.  Some examples might be a Hunter considering Leather armor, or a Resto Shaman considering Cloth. To enable such considerations, simply pull up Tools > Refine Types of Items Listed, and enable / disable what items you would like to consider as applicable.

* **{anchor:16}Q:  Why isn't my Hunter doing any DPS in the charts?**
	* A:  You probably haven't selected your Ranged Weapon yet. Check that first, then check your Talents, then Buffs, then Rotation, then Pet selection
