# **Posting Guidelines**

In order to streamline the communication between you (the end user) and us (the Rawr developers), we've setup these posting guidelines. When posting to our Discussion board or Issue Tracker, we ask the following things from you:
# You put as much time and effort into searching previous issues and discussion topics as you want us to spend addressing your issue.  A large number of the questions that are asked have already been answered when they were asked previously.  Not only will it save us the time of readdressing the issue repeatedly, you can typically find the information in much less time.
# You make an effort to use proper English, including correct capitalization and punctuation. Avoid "leet speak", excessive non-traditional abbreviations, and other such nonsense. We understand that not all Rawr users are native-English speakers, and will do our best to understand you, when you do your best to be understood.
# You keep your conversation civil and polite. If you disagree with something that has been posted, support your point of view with analysis, extensive testing to prove you've put some time and thought into it.
# You only create a new post if you have something to discuss. If a topic has been spoken about previously, please post in the existing thread rather then starting a new one.
# If you are having general problems with Rawr, such as it not launching, Armory import issues, etc., please read this: [Troubleshooting](Troubleshooting)
# If you are reporting a bug, follow the bug report format found here: [Bug Reporting Format Guide](BugReportingFormatGuide) and only post it to the Issue Tracker, not Discussions.
# If you are requesting a feature, follow the feature request format found here: [Feature Request Format Guide](FeatureRequestFormatGuide) and only post it to the Issue Tracker, not Discussions.
# If you don't understand why Rawr is telling you to gem, enchant or gear a certain way, please read this: [I Don't Understand Why...](IDontUnderstandWhy)

# Bug Reports go in the Issue Tracker!

We want the discussion boards here to be a forum for discussion on theorycrafting, programming and well, Rawr. By following the above guidelines, hopefully your questions will be answered quickly and effectively. Failure to abide by these rules will result in your posts being linked to this page as a response and being otherwise ignored by the staff of this project.
