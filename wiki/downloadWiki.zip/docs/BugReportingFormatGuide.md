# **Bug Reporting Format Guide**

 In order to cleanly track what bugs and feature requests we have in Rawr, we ask that users provide the following information when posting bugs to the Issue Tracker.

* **Title** - This should outline what category (either the model, if it's model specific, or the high level feature like Comparisons, Optimizer, etc) the bug is in, and a quick description of the issue. If unsure about the category, just leave it off, and we'll adjust it as needed.
* **Description** - This should be no longer then a paragraph, it should outline quickly what is broken/not working.
* **Steps to Reproduce** - Exactly what it sounds like, these are the steps to reproduce the bug in question.  You should start with launching the application.
* **Version Number/Additional Information** - What version of Rawr you are running, your OS, the stacktrace and error message. Please note that large error messages, such as are what usually produced during a crash in Rawr, should be saved to an error.txt file and attached to the Issue instead of posted into the description. This allows cleaner formatting and less scrolling for the Developers that intend to fix the issue.
* **Details** - On the right side of the page, please fill out the Type (Issue), Release (the version #), and Component (if it's there).
* **Attachment** - Attach your character file that reproduces the issue.

## **Example**

**Title:** {"[Item Editor](Item-Editor)"} Crash on Item Edit
**Description:** Rawr crashes when I edit a helm item.
**Steps to Reproduce:**
# Launch Rawr
# Tools > Edit Items
# Select Bloodfang Mask
# Change Agility Value from 112 to 113
# Click the "OK" button
# Observe that Rawr Crashes
**Additional Information:**
* Rawr v2.2.23
* Windows 7 RTM
* System.NullReferenceException: Object reference not set to an instance of an object.
**Attachments:**
* CharacterWithBug.xml