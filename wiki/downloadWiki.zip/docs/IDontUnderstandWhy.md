# **I Don't Understand Why...**

So you've come to this page because you don't understand why Rawr is telling you to gem/enchant/gear a certain way.  Before you open an issue and report a bug, we ask that you take a look at the following list of commonly forgotten options that could be changing the outcome.  If you find that your question is not answered here, please further refer to our [FAQ](FAQ), including model-specific issues.  If, _**after**_ you have read over both of these pages, you still have an unresolved issue with your character profile, you should then proceed to the steps at the bottom of this page.

* **Buffs** - Check all raid buffs that you would have in your normal raid.  Generally a 25man raid will have "all" buffs where as a 10 man raid will only cover some of them. If you're unsure what buffs you'll have, you should use at least a decent level of buffing in Rawr (since the optimal gearing choices for someone unbuffed is _vastly_ different from someone even partially buffed).
* **Options** - Depending on the model of Rawr you are using, options found here may include options which will GREATLY affect the value of certain stats and talents.
* **Gemming Templates** - Tools > Edit Gemming Templates.  Ensure that the Gemming Templates include the Gems that you have available to you.
* **Main Panel** - Check "Enforce Gem Requirements".
* **Chart Panel** - Ensure that all gear, enchants and gems that you have available are marked available (mark available using the diamond to the left of the item/gem/enchant). See the [Gear Optimization](GearOptimization) page for details.

Once you have everything above configured correctly, there are still several reasons why results may differ from what you expect:

* **Metagem Requirements** - Certain gemmings of items may be rated much higher than otherwise superior gemmings due to them activating your metagem.
* **Set Bonuses** - When swapping pieces of gear involved in sets, you may be gaining or losing various set bonuses, which can have a drastic effect on your performance.
* **Unstable Stats** - Several stats vary in value by quite a bit, even when making small changes (especially haste), since they can change your rotation. Models attempt to smooth that out to varying degrees, but it is definitely still a significant source of instability.

If you've double checked the above mentioned settings and possible causes, and you're still confused as to why Rawr would suggest for you to Gem/Enchant/Gear a certain way, please do the following:

# Before doing anything else, please check our [FAQ](FAQ), and don't forget to check for model-specific issues.
# Search for an existing entry in the Issue Tracker for the issue you're experiencing.
# Read the [Bug Reporting Format Guide](BugReportingFormatGuide).
# Post a bug report describing the issue.
# **Attach your character file to that issue.**
