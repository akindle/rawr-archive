# Tanking Formulas
The idea here is to provide a base description of how each value is calculated on abstract terms.  This is not a place to copy any paste the actual code, but rather give the goal of each value so that the community has an understanding (at least in [Rawr.TankDK](Rawr.TankDK)) what the values mean.

Some issues in the TankDK module that I'm seeing:
* The balance of Survival and Mitigation ratings still feel disjointed, whereas in reality, tanks are constantly trying to balance these two.  Mitigation doesn't actually help with damage spikes, that's all Survival, but the current math, supports Mitigation over Survival when the damage increases.  I want to shift this so that there is a clear balancing act in the values.  At some point, if the damage potential in burst/spikes exceeds your Survival score, the character needs to stack more Survival, and not more mitigation.  This is shown in some ways using the Burst/Reaction graph, however, I believe it should be possible in the SMT graphs as well.  
	* If the raw incoming damage is 100k, and your survival score is only 90k, the tank will die.  No amount of mitigation is going to protect them from it, and yet the current math suggests that it may.  

## Survival
Hit Points * Static Damage Reduction
This is basically the idea of how much damage can you take before you die. (Ideally in 1 shot.)
Static Damage Reduction is Armor Damage Reduction to physical damage as well as Magic Resistance Damage Reduction to magical damage.  In [Rawr.TankDK](Rawr.TankDK), I take the single max resistance value to help the tank evaluate the damage if it's magical will be in 1 school, and the tank is gearing up for that school.  I expect to later expand this to detail out each school as in the [Rawr.ProtWarr](Rawr.ProtWarr) module.
These numbers don't change by adjusting the incoming damage directly, but DO change based on changing the KINDS of damage that you may be receiving.  EG: Your survival may go down if a fight shifts from mostly physical to mostly magical damage without the same level of magic resistance.
* A good write up for the full weight of Survival/Effective Health: [http://maintankadin.failsafedesign.com/forum/index.php?f=6&t=26831&rb_v=viewtopic](http://maintankadin.failsafedesign.com/forum/index.php?f=6&t=26831&rb_v=viewtopic)

## Mitigation
Damage mitigated In Damage per Second.  
Use the Mitigation Weight to increase or decrease the duration of damage evaluation.
All other damage reduction falls here.  Usually these are proc or cool-down based.  These will change based on how much damage is incoming.  
* Damage reduced by Crit mitigation
* Armor Damage reduction
* Damage reduction from talents.
* Dodge/parry/miss
An article that has some good formulas: [http://www.tankspot.com/forums/f200/37241-power-avoidance-preliminary-results.html](http://www.tankspot.com/forums/f200/37241-power-avoidance-preliminary-results.html)  I'll be working to see about integrating what he writes there into what we can do in Rawr.

## Burst
This is all those things that help deal with incoming damage bursts.  For DKs this includes Death Strike Heals and Blood Shield, but additionally, this includes all On Use trinkets and cooldowns.  
* Any CD based abilities using average mitigation over time.

## Threat
Threat caused in the shot rotation over the course of the rotation * the number of targets detailed in the options * any Threat modifiers.
For the most part, threat is modified by presence/stance.  
Only abilities that could damage multiple targets are actually multiplied by that value.  For abilities like HeartStrike that only target 1 or 2 targets, that's as much benefit you'd find. 
This is so tanks could adjust their talents and abilities for single vs. multi-target situations.