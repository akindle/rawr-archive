# **Feature Request Format Guide**

There are many _**many**_ times more users of Rawr than there are of developers of Rawr. So, it's expected that you'll think of great ideas for features more than we will. As such, we'd love to hear about them, so that we can prioritize them, design them, get them developed, and released. However, us developers are usually much more familiar with the inner workings of Rawr, what pieces all depend on what other pieces, the big picture, etc. So, we're more interested in hearing what the problem you want to solve is, than how you want us to solve it. Of course, hearing how you envision us solving it is great, and very helpful, we just always need to know the problem you're trying solve first. **Please post feature requests in the Issue Tracker.**

* **Title** - This should tell us that this is a feature request and contain a short description of what the feature is.
* **Description of the Feature Request** - You should focus this section not on how you want the feature to work, or how it should be implemented, but on what you can't do that your feature would allow you to do.
* **Suggestion for Fix** - This is the section where you may describe how you want the feature to work, and/or how you think the feature should be implemented.  Please keep in mind that we may not decide to implement the feature this way, or at all.
* **Any Additional Information** - Any additional information you feel is needed that doesn't belong in the other two categories.
* **Details** - On the right side of the page, please fill out the Type (Feature), and Component (if it's there).

## **Example**

**Title:** {"[Feature Request](Feature-Request)"} Locked Chart Headers
**Description:** I often swap between different characters/models, and forget what the different colors of bars mean, so have to scroll up to check quite often.
**Suggestion:** Lock the header of the charts so that it doesn't scroll with the rest of the chart.

In this example, we would review the feature request, and may think of a better way of solving the issue (such as standardizing the colors/names of the ratings across all models), or go with the suggested fix, or do both. The important thing is that given the problem, we can find the best solution.
## **Feature Requests go in the Issue Tracker**