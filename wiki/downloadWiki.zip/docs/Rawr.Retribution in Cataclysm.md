# Rawr Retribution in Cataclysm.
No actual development has been done towards making Rawr.Retribution work with Cataclysm in mind. The beta is still way too dynamic to start building a model around. But that doesn't mean no preparation at all has been done so far. This page serves both as a means to tell you what the state of affairs is, as well as a reminder for myself as to which info I still need to solidify. Consider it a Rawr.retribution cataclysm blog.

Rotation wise, I am fairly confident I will be moving towards a statistical model rather than an FCFS simulator (or any other kind of simulator). The simulator approach in Rawr.Retribution now was added by the previous developer (Ermad) and has since been enhanced/improved. The problem is that it causes erratic behaviour in relation to haste. And with adding in the 2T10 bonus, it is a major cause of performance issues.  A statistical model should remove the performance issues, and should end up giving a less erratic result for changing values of haste.


## 25 August 2010
Cataclysm Build 12759 (to date we're already somewhat further, I have just been slow :p) changed Divine Purpose to 'Judgement, Exo, TV, DS, Inquisition and Holy Wrath all have a 40% chance to generate Holy Power'

DPS wise, we will always want to have 3 stacks of HP up, with the possible exception of needing to finish early because a 'no attack' phase is coming up and you would loose the partial stack of HP otherwise.
This means there are 4 possible rotation 'fragments' that can happen.
# CS x CS y CS Finisher  (Neither the previous finisher, nor x nor y proced HP.  Chance: 60% * 60% * 60% = 21.6%)
# CS x CS y Finisher  (Neither the previous finisher nor x procced, y does proc.  Chance: 60% * 60% * 40% = 14.4%)
# CS x CS Finisher  (Previous finisher or x proced HP.  Chance: 60% * 40% * 2 = 48%)
# CS x Finisher  (Previous finisher and x both proc HP.  Chance: 40% * 40% = 16%)
_Finisher_ is one of the abilities using holy power (Templar's Verdict, Inquisition or Divine Storm).
_x_ and _y_ are 'filler' abilities (Judgement, Exorcism, Holy Wrath, Hammer of Wrath, maybe Consecration although mana usage may make this impossible).
All of the above chances add up to 100%.  Proof that those are indeed all of the possible cases.
Both 2 and 4 cause a next CS to be delayed somewhat. Depending on actual numbers at 85, it is entirely plausible that while technically possible, it won't be smart to actually do this and hitting CS instead (causing 1 HP to be wasted) will do more DPS.

Now all that needs to be done is substituting x and y with actual abilities, taking into account their cooldown and priority.  Pen and paper math so far says J > HoW > Exo (if AOW proc) > HW.   Although with HoW not having a chance to proc HP, it may end up lower.   x, y can also be blank if nothing is off cd, or may end up being used for utility.  

Talents and CD's are still being changed.  Glyphs and damage numbers at 85 are still unknown so not much more can be done in this area for now.

Another 'problem' is figuring out how to make best use of the Inquisition buff. Is it something you really want to have up 100% of the time and need to refresh early, or something you can let drop off for short amounts of time.  Again, we don't know glyphs and it isn't impossible there will be a glyph that increases the duration of Inquisition.



