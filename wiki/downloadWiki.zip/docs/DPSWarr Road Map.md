# DPSWarr Road Map
(these are not in any particular order unless stated otherwise)
* General
	* Add calculational effectiveness for Self-Healing Targets (mobs that heal themselves)
	* Add Threat Handling
		* Many warriors do lots of extra threat and we have no Threat drops other than to stop DPS, talents that reduce this become useful
		* We might also want to set caps on Threat, forcing rotations to break)
* Abilities
	* General
		* Add Hamstring Handling (Requires Moving Targets)
	* Arms
		* Add Mortal Strike Healing Reduction Handling (Requires Self-Healing Targets)
	* Fury
* Buffs
	* Add Pots handling (needs to pull GCDs if being used, verify that they actually do before doing this)
* Talents
	* Arms
		* Add Improved Hamstring Handling (Requires Hamstring Handling)
	* Fury
		* Add Piercing Howl Handling (Requires Multi-mob Targeting)
		* Add Blood Craze Handling (Requires Damage Taken Handling)
		* Add Furious Attacks Handling (Requires Self-Healing Mobs Handling)
	* Protection
* Glyphs
	* Add Glyph of Hamstring Handling (Requires Hamstring Handling)