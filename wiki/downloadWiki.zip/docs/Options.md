# Rawr Options

Rawr options allow you to customize the behavior of Rawr. Most of the users will never need to change the settings, but they are there to let the more advanced users modify Rawr to their specific needs.

## General Settings

##### Use multithreading
* Rawr is designed to take advantage of multi-core processors and will by default compute several gear calculations in parallel when calculating comparison charts or optimizing your gear. You can disable this to force Rawr to only utilize one thread.
##### Display Buff Sources
* You can enable this to display which class/spec provides the buffs in the Buffs tab.
##### Display Gem Names in Tooltips
* You can enable this to display the names of gems in addition to their stats in item tooltips.
##### Enforce Profession Requirements
* When enabled it will hide all buffs, enchants and options such as jewelers gems and blacksmithing sockets that you don't have access to based on your selected professions.
##### List Names Width
* Determines the width of column reserved for item names in comparison charts

## Special Effect Settings

##### Proc Effect Calculation Mode
Determines the way uptime of special effects is calculated.
* Simple - This is the fastest way, using the asymptotic uptime as fight duration goes to infinity.
* Advanced - Low Precision - Computes accurate uptime based on given fight duration using single precision when calculating values of incomplete beta function.
* Advanced - High Precision - This is the most accurate, but slowest method. It computes uptime based on given fight duration using double precision when calculating values of incomplete beta function.
* Advanced - Interpolation - This method precomputes high precision values at specific proc chance and interval points and then uses interpolation to compute values at other proc chances and intervals. It is relatively fast while still giving very accurate results.
##### Effect Combinations Calculation Mode
Determines the way combined uptime of several special effects is calculated. All methods use adaptive Simpson's method for numeric integration of average uptime over time. The methods differ in how the incomplete beta function values are calculated that are used to compute average uptime at specific time points.
* Interpolation - Linear - Uses linear interpolation to compute values of incomplete beta function. Fastest, but least accurate.
* Interpolation - Cubic - Uses cubic interpolation to compute values of incomplete beta function. Relatively fast, medium accuracy.
* High Precision - Double precision calculation of incomplete beta function using P series or continued fraction expansion.

## Optimizer Settings

See [Gear Optimization](GearOptimization) for more details on gear optimization.

##### Enable warnings in optimizer
* By default you will be warned when the optimizer considers that you're using suboptimal settings such as having too many items selected available or not having something marked available that you have currently equipped. You can uncheck this to disable those warnings.
##### Consider gems in enabled gemming templates to be available
* When enabled the gems in enabled gemming templates will be available to be used by the optimizer when regemming items.
##### Optimization Method
This determines the primary search method used by the optimizer.
* Genetic Algorithm - This is the default way the optimizer is searching for optimum gear setups. When optimizer is searching for optimum it will use a population of characters which it combines and modifies to find better gear setups. More details on [Wikipedia](http://en.wikipedia.org/wiki/Genetic_algorithm).
* Simulated Annealing - When optimizer is searching for optimum it will only modify a single character, starting with large changes and minimizing changes the closer it gets to the optimum. More details on [Wikipedia](http://en.wikipedia.org/wiki/Simulated_annealing).
##### Greedy Optimization Method
This determines the search method at minimum thoroughness or when making a final pass after main search is complete.
* All Combinations - When looking for direct upgrades in a slot it will evaluate all possible gemming and enchanting combinations for all gear marked as available.
* Single Gem/Enchant Changes - When looking for direct upgrades in a slot it will only try modifying one gem/enchant at a time. This speeds up the search, but if two gems need to be changed at the same time to get an improvement it will miss that.
* Greedy Best Gem/Enchant - When looking for direct upgrades in a slot it will first determine which gems/enchants are best based on relative stat values and try putting in the best based on socket colors or best overall. This method is the fastest, but will give the worst results.