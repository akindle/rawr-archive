# ProtPaladin Frequently Asked Questions (FAQ)

The issues here are ProtPaladin-specific issues. Please refer to the [general FAQ](FAQ) for more program-wide support.

* [When I calculate Effective Health, Tank Points, or Burst Time manually, I come out with a number that is lower than what Rawr is calculating.  Why?](#LowerCalc)

----

* **{anchor:LowerCalc}Q: When I calculate Effective Health, Tank Points, or Burst Time manually, I come out with a number that is lower than what Rawr is calculating.  Why?**
	* A: ProtPaladin takes into account whether or not you are spec'd into Ardent Defender, the talent that reduces the damage you take below 35% health.  This talent increases the amount of damage you can take, thus raising your Effective Health, Tank Points, and Burst Time by 8.75% if you have spent all 3 points on the talent.  Note that it does NOT model the self-resurrecting portion of Ardent Defender, only the damage reduction portion.