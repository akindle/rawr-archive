# Buffs
Buffs are an important part of any character, with them we take our measly DPS numbers and become mad powerhouses of carnage. Buffs in Rawr consist of Raid Buffs such as Blessing of Might, Raid Debuffs such as Demoralizing Shout, Set Bonuses, such as Stormrider's Raiment, Flasks/Elixirs such as Flask of Stoneblood, Potions such as Earthen Potion, Food such as Strength Food, Scrolls such as Scroll of Agility IX, Professions such as Toughness from Mining, and a few other points.

_Scroll to the bottom to see common troubleshooting for Buffs._
## The Buffs Control
**The Buffs Control** is a **Tab** located at the **Top of Rawr on the Left Side**. It can be found between the **Talents** and **Options Tabs**. From here, you can use simple CheckBoxes to Check a Buff as being active or not. You will notice each Buff has several in the same Buff Group. In most cases, Buffs inside the same Buff Group are exclusive, meaning you can only have one active at a time. This mimicks in-game behavior where you can only have one at a time. In some cases, you may be able to select more than one of the same buff group because they either do not conflict with something else or were simply placed in the same group for ease of location. This is true for Temporary Power Boosts like Hysteria and most Resistance buffs like Frost Aura.

Set Bonuses and Profession Buffs cannot be manually selected. To enable a Set Bonus you must be wearing at least that many peices in the set at that time. Profession Buffs can be enabled be selecting the appropriate profession on the Stats pane. Both of these should happen when you load your character from the Armory or Addon, you should not need to perform any extra steps to make it happen.
## Why should I select Buffs?
Without Buffs, you would essentially be optimizing your character to perform solo, not in a raid. This has **drastic** consequences on gearing your toon. You could be close to Crit Cap yourself and a Buff in a raid would push you over, thus wasting more Crit that you could have moved to Haste. Similar situations with Dodge, Parry and other stats occur nearly every single time. A common scenarios is to be a Tank and have stacked well stamina above what you actually need and should be stacking Mitigation stats.
## What Buffs should I select?
There are a few ways to figure out how many and what Buffs you should select.
# **Select Buffs by Raid Members:** This method is for those users who are very unfamiliar with what buffs they have in their normal raids. The Dialog that opens by clicking the button will ask the user to input the raid members they normally run with. Once filled out, they will press OK and see their Active Buffs automatically populated with Buffs.
# **Fully Buff:** Users who know they are in well-balanced 25 man raids can commonly just select one of every buff group.
# **Selectively Buff:** Users familiar with what raid buffs they normally have in their 10 or 25 man raids can select the related CheckBoxes on the pane manually. This is the most common method of selecting Buffs.
# **Use the Defaults:** Some models provide Default Buff assignments to your character when it is loaded from the Armory or Addon. These are to provide the user with an immediate set of buffs to work with. Note that not all models do this and just because it's empty by default does not mean you should operate Rawr without buffs.
## What are Buff Sets?
Many users find themselves in different raids throughout the week, from 10m Normals to 25m Heroics. To ease the burden of selecting and deselecting and reselecting your raid buffs whenever you change raids we have added the ability to select a list of buffs, then save that list as a **Buff Set**.

This is accomplished by building out your list of Buffs then pressing the **Save** button at the top of the **Buffs Control**. A dialog prompt will ask you for either a new unique name to save the list as or to select a previous Buff List to overwrite.

Some model Devs have provided a "Fully Buffed X" buff set for users to see how this works.
## Common Questions about Buffs
* Why can't I select x Buff? It's grayed out to me
	* You have already selected another Buff that this one Conflicts with. Unselect the other Buff to select this one
* Why can't I select x Buff? It's missing
	* Some Buffs are not relevant to your current toon, such as a SpellCrit buff for DPS Warriors. These Buffs will not show up to those toons.
* I can't see my Mixology Bonuses to Flasks/Elixirs
	* Check your Profession on the Stats Pane, you may not have Alchemy selected.
* I can't see my Engineering Bonuses to Pots
	* Check your Profession on the Stats Pane, you may not have Engineering selected.