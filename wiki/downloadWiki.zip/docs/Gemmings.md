# Gemmings
Gems are a very important part of a character, and properly optimizing them is essential to good performance. They complicate and confuse things, and have previously been a pain to handle in Rawr. As of Rawr v2.2, however, a new gemming system is in place, to ease those pains. In order to properly compare a socketed item to other socketed items, and other non-socketed items, we need to fill those sockets. To fill those sockets, we use something called Gemming Templates.

## Enforce Gem Requirements
This option, located in the Options dialog, performs the following adjustments to the Gem flow on your character:
# Deactivates the Meta Gem unless you have the required gems available elsewhere. For Example, the [Chaotic Shadowspirit Diamond](http://www.wowhead.com/?item=52291) requires more Blue Gems than Red Gems and if your character is using Red gems in every socket, you would not meet the requirement.
# Prevents more than 3 Dragon's Eye Gems (or in Cata, Chimera's Eyes) from being active. With 4+ equipped, they are ALL disabled until the number of equipped is reduced to 3 or less.
# Prevents Unique-Equipped Gems from having more than one equipped (if more than one, then they disabled in same fashion as above Dragon's Eyes). An example of this is [Nightmare Tear](http://www.wowhead.com/?item=49110)
# This option does **NOT**, we cannot stress this enough, does **NOT** force all Blue sockets to only use Blue Gems, etc.

## What is a Gemming Template?
Simply put, a Gemming Template is a plan for how to fill each color of socket. For example, as a Mage, one viable gemming template would be to fill red and prismatic sockets with Runed Scarlet Rubies, yellow sockets with Reckless Monarch Topazes, blue sockets with Glowing Twilight Opals, and meta sockets with Chaotic Skyfire Diamonds. That's just one viable gemming template, though. In order to find what the best way to gem an item is, for a given situation, we need to compare a variety of different gemmings of the item. Rawr comes with dozens of gemming templates pre-defined for each model, and you can easily enable/disable them, and add custom ones.

## How does Rawr use Gemming Templates?
It's also important to note that unlike the old gemming system, gems are not 'saved' with each item. There are no longer copies of each item in the item cache for each gemming. Instead, just the ungemmed item data is saved, and gemmed versions of the item are dynamically created, as needed. In the charts, only the top 3 gemmings of an item are displayed, to reduce clutter you can customize that number on the Edit Gemming Templates dialog. 

When comparing a socketed item, Rawr will create gemmings of it to fit all _enabled_ gemming templates. If multiple gemming templates would result in the same gemming, only one gemming will be created for those templates. In this way, you don't have to manage gemmings anymore, just gemming templates (plus the defaults are useful to the majority of users, and easily changed for more advanced users).

## Editing Gemming Templates

![](Gemmings_http://dl.dropbox.com/u/15727672/RawrVisible/WhereToStart/EditGemmingTemplates.png)

Each Rawr model comes with built-in gemming templates to correctly handle almost any situation, using all the different of qualities (uncommon/rare/epic/jeweler) of gem. By default, the gemming templates to satisfy the majority of situations, using Rare quality gems, are enabled. All other built-in gemming templates are disabled. It's quite easy to enable or disable gemming templates, however.

Go to **Options > Edit Gemmings Templates...**, to bring up the Gemming Template Editor. In the main panel of this window, you will see all of the currently defined gemming templates, in various groups. To enable a gemming template, check the Enabled box next to it. Or to disable it, uncheck that box. You can also quickly enable/disable entire groups by checking/unchecking the box next to that group.

At the bottom of the list of gemming templates will be an **Add** button. You can click Add, to create a new blank gemming template under the Custom group. Custom gemming templates can be deleted as well, using the Delete button. Built-in gemming templates can only be disabled, not deleted. 

## Custom Gemmings
It is also still possible to create specific custom gemmings of an item, for one-off situations.
* Equip the item
* Select the gemmings, enchanting, reforging and tinkering you want for this item instance
* In the related gear slot chart, shift-click the diamond to make it blue per the [Optimizer](Optimizer) documentation
* You can now equip your original item if you would like
To remove the custom gemming, shift-click the blue diamond again. Please remember that these custom gemmings are intended to be used for abnormal exceptions; if you find yourself regularly using Custom Gemmings, you probably should just add a new Gemming Template.

## Gemming Templates and the Optimizer
The optimizer does not use gemming templates; it will mix and match from all gems that are marked "Available to the Optimizer". However, there is an option (enabled by default) to count all gems in enabled gemming templates as Available to the Optimizer. Because of this, it's likely that you won't need to mark any gems available, unless gems that aren't included in any enabled gemming template are possibly of use to you.