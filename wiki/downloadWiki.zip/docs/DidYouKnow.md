{"-------"}
You can save talent builds by clicking the Save button, and then compare different builds in the Talent Specs chart.
You can use the All Buffs chart to find the best food, elixir, or flask for your character.
By marking the green diamond next to items, gems, and enchants, you indicate that you have them available to you. The Optimizer can use that information to find the best set of gear available to you, or to build a list of potential upgrades for you, and their upgrade values.
When using the Optimizer, you can use the Additional Constraints feature to enforce requirements such as being uncrittable, being hit capped, maintaining a certain level of survivability, a minimum haste %, and much much more.
You can use Batch Tools to figure out which spec of yours performs the best given your gear!
Rawr Batch Tools can help you find gear that's an upgrade for more than one of your specs!
The direct-upgrades chart will quickly show you where your current gear is lacking.
If you can never remember which class gives which buff, you can set an option to display the source of each buff in Tools : Options : General Settings.
You can select which language (English, French, German, Spanish, Russian) to view the item names in by selecting your language in Tools : Options : General Settings.
In addition to the gems you mark available, the Optimizer will also use any gems included in any enabled Gemming Template. You can disable that in Tools : Options : Optimizer Settings, if you prefer to manually choose what gems are available.
You can choose which gemming templates Rawr uses to gem items in the charts in Tools : Edit Gemming Templates.
Jewelcrafters can tell Rawr to use their Dragon's Eye gems by ticking the Jeweler gems section in Tools : Edit Gemming Templates.
You can force the Optimizer to use only a specific gemming of an item by CTRL-clicking the diamond in the gear list (it will turn blue).
You can force the Optimizer to use only a specific enchanting of an item by right-clicking the diamond and selecting the enchant (it will show a red dot).
Upgrade Lists provide a huge advantage over the simple comparison charts. The comparison charts will show you the values for individual items, while the Upgrade List will show you each item's upgrade including the optimal combination of items that you have available to go with that item. Use Tools : Optimizer : Build Upgrade List to get started!
If Rawr is valuing items for your caster character which focus on mana regen higher than you'd expect, you may be running out of mana. Ensure that you have all the appropriate buffs checked, especially for mana regen.
You can set an option in the Tools : Options menu to show or hide profession buffs that your character doesn't know.
You can view your character in 3D on Wowhead.com by using the menu off the Tools menu.
{"-------"}