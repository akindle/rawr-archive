# DPSWarr How To Guide

* [#Basics](#Basics)
* [#Advanced](#Advanced)
Please note that this page assumes you are familiar with Rawr's basic functions, such as selecting gear and running optimizations. For more info on this, see the main [Documentation](Documentation) page.
{anchor:Basics}
### Basics
To begin, assuming you have already imported your character from either Character Profiler or the WoW Armory, select your talent specialization on the Ability Maintenance Tab as either Fury or Arms if it did not do so automatically. If you would like to check your numbers against information from the next patch (at present, this is 3.3) you can enable 'PTR Mode' on the Misc Tab.

Next, jump over to the Misc Tab and check out the following:
* Lag is the average Latency reported in your WoW client. Many with broadband connections usually see a value between 100 ms and 200 ms. Those with slower connection types such as dial-up will see much larger numbers.
* Reaction is the average amount of time it takes for you (the player) to react to a button that becomes available. For example, when an opponent dodges and the Overpower ability procs, how long does it take you to process this mentally and command your finger to push the hotkey for Overpower. The WoW client gives 250 ms (1/4 second) allowance for this before your reactions count against you. Most players fall under this 250 ms rule.
* NOTE: Lag and Reaction are combined into a single calculable value. Small adjustments to these numbers yield **very** small adjustments in your DPS.

Now jump over to the Boss Selector Tab to set some background rules for the fight you want to measure against.
* The Boss Selector is a new method of using defined Presets for your 'Situational' settings. Selecting a specific boss will tailor the Duration, in back time, multiple targets etc to what is necessary for that fight. Please note that as this is a new method, many of the values for the presets still need to be fine-tuned.
* Target Level can be changed from 80 to 83. 83 is the numeric representation of all Raid Bosses (who show themselves as Level '??')
* Target Armor is currently defaulted to 10,643 for all Level 83 Bosses. This is the accepted rule of thumb and there is little reason to change off of this.
* Fight Duration is the length of the fight in seconds. A value of 600 is 10 minutes. Most boss fights take 6 minutes (value 360) or less but we left a high upper value for those wanting to see total damage for a greater period of time. The maximum for this box is 20 minutes, just above KT's Enrage Timer, which is a value of 1200.
* The Situational boxes provide the basic situation you will normally be fighting in. The default setting should be all disabled except 'Standing in Back' at 100%. See the [Advanced Instructions](#Advanced) for more info on these settings.
Finally, go to the Ability Maintenance Tab and choose the abilities you will be maintaining during your battles. Note that changing one or the other can have serious effects on your total DPS output, and some abilities act differently if you are in different situations. For example, Bladestorm will have a much larger DPS number if there are multiple targets throughout the fight.
NOTE: If you have Flooring active, turn it off unless you really want to see what it does. The methods behind it have not been refined and it is presently not as accurate as having it disabled.
{anchor:Advanced}
### Advanced
**NOTE:** This section is for advanced users only, most players do not need to concern themselves with these settings.

Since you have gotten your feet wet, looked at your gear, maybe even run an optimization or two, now you must be hungry for more. Fear not, there's plenty more you can tweak with your character.

#### The Ability Maintenance Tab

Select additional abilities to watch how they affect your DPS. Thunder Clap applies a debuff to bosses as do Sunder Armor, Demoralizing Shout, Shattering Throw, etc.

#### The Misc Tab
* **Survivability Scale:** Set the Scale from 0.0 to 10.0 (Default 1.0) for values that provide Survivability. Note that this does **not** relate to Survivability as defined by the Tanking models. If you aren't worried about Survivability, set it to 0.0, but if you are having a hard time staying alive in Boss fights, increase the scale.
	* Survivability value is the sum of:
		* Self Heals per Second E.g. Bloodthirst Healing Effect
		* Health E.g. Commanding Shout
		* Damage Taken Reductions E.g. Blessing of Sanctuary
		* Boss Attack Speed Reductions E.g. Thunderclap
* **Use Duration for Special Effects:** This can be set to prevent issues where the Fight Length can skew the values of proc effects like Mirror of Truth. A one second difference in Fight Duration could mean an extra activate, this prevents that and allows generic per second values.
The following options hide Items, Buffs, Gems, etc. that are irrelevant to DPSWarr on a Stats basis unless it has a specific reason not to be, like Powerful Stats still should be shown. Turn all of of these options off for normal behavior based solely on Item Type and having any kind of stat relevent to DPSWarr. 
* **Hide Defensive Gear:** Hide if the object has Defense Related Stats (Defense, Dodge, Parry, Block).
* **Hide Spell Gear:** Hide if the object has Casting Related Stats (Mp5, Spell Power, Mana, Spirit, Spell penetration).
* **Hide PvP Gear:** Hide if the object has PvP Related Stats (Resilience).
* **Hide Enchants Based on Professions:** If you don't have the selected professions, Enchants that require those will be hidden. E.g. Non-Engineer's won't see the Hyperspeed Accelerators Glove Enchant.