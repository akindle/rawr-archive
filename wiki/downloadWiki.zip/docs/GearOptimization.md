# Gear Optimization

Aside from using the comparison charts to decide which gear is better, Rawr provides you alternative more powerful tools to answer several questions regarding gear optimization. There are two general questions that it can answer. Given a set of gear options it can decide which subset gives the best value given some constraints. It can also answer how much improvement in value you will get by adding a particular item to the gear options. Both questions can be answered by the optimizer tool that is found in Tools->Optimizer.

## Available Gear

For the Optimizer to decide which gear gives the best value it has to know what it can choose from. This is done by marking items/enchants/gems as available in the comparison charts. Exactly what to mark as available will depend on which question you are asking and you can see some examples in the Examples section.

There are several levels of specifying in what way a particular item is available and this is indicated by the diamond in front of the item name.
![](GearOptimization_http://dl.dropbox.com/u/15727672/RawrVisible/WhereToStart/OptimizerDiamonds.png)
* Empty diamond: item is not available for optimizer
* Green diamond: item is available for gemming and enchanting
* Blue diamond: this particular gemming/reforging/tinkering/enchanting of the item is available

Which gemming and enchants will be considered for items that are marked without gemming or enchanting restrictions is determined by which gems and enchants are marked as available. Marking an item available does not imply that its gems or enchants are marked available. You do need to mark enchants and gems available, on their respective charts. NOTE: Gems in active gemming templates (see [GemmingTemplates](GemmingTemplates)) are considered available by default. This is an option you can turn on/off in the Options dialog. 

To mark an item with green diamond you left click on the diamond. To mark it with blue diamond you Shift-click on the diamond. Note that an item can be marked as both available in the specific gemming variant and available for gemming using available gems. For example if you would like to in general consider some gems for all items, but have an exception for some items, then you would mark which gems are available for all and then for the items that do not follow the general rule mark them with blue diamonds for just the gemmings you want.

There are two options in the optimizer that override these settings. If you select "Override Regem" then all items marked with blue diamonds will be also considered available for gemming with gems that are available (as if they had green diamonds). If you select "Override Reenchant" then all items that have enchanting restrictions will also be available for enchanting with available enchants (as if they didn't have a red dot).

## Knowing What to Mark Available

The more you mark available, the slower, and less accurate, the Optimizer will be. So, what should you mark available? Simply, anything that has a chance of being useful in building an optimal gear set. If you're not sure, mark it, but use common sense. Obviously, there's no need to mark a 12agi gem available, as well as a 16agi gem. Nor should a mage mark an agi/mp5 gem available, or a rogue mark a stam/spellpower gem available. A good guideline is about 5 or less available items per slot. The Optimizer will display a warning if you try to optimize with an extremely large number of available items in a slot.

## Optimization Settings

Before proceeding with optimization you have to select which calculation you want to optimize and any possible additional requirements. The options available will depend on the model you are using. You will always have overall rating, subratings and any additional calculations provided by the model. The requirements come in the form of constraints by specifying that a certain rating has to be either lower or higher than a certain value. These are considered hard constraints, meaning that the optimizer will first try to meet all the constraints and only then will it optimize the calculation you selected.

Final setting is Thoroughness which determines how extensive the search performed by the optimizer will be. At minimum setting the optimizer will only look for direct upgrades. In general the higher the thoroughness is, the longer the search will take and more likely it is that the optimizer will find the true best combination. Note however that even at highest setting the optimizer is not guaranteed to find the true answer.

## Optimizer Technology

Searching for best gear is a very hard problem. More of the same stat does not always give better value and things like set bonuses make the search space quite interesting. Rawr implements two stochastic search methods that are in wide use for difficult optimization problems, simulated annealing and genetic algorithms. Genetic algorithm is used by default, but you can change that in the optimizer settings found under Tools->Options.

In both cases we first generate a list of all available gear according to how the items are marked and override settings. Both search methods start by generating a random character from available gear and then make changes to it trying to find improvements. Simulate annealing works on a single character and makes changes to it. Genetic algorithm on the other hand is keeping a larger population of characters and in addition to modifying them also mixes features from different characters (it is using a multi-island variant of the algorithm).

By their nature neither algorithm can guarantee to find an optimum solution. To achieve that we would need to perform an exhaustive search of all possible combinations of gear, which is not feasible due to the huge number of options (literally, this could take eons to calculate).

## What If I need Higher Thoroughness than what the Slider provides?
If you Ctrl+Click the Optimize button, it will run at 10x the thoroughness of the slider. This is intended to give users with extra time the ability to go through more iterations of combinations of gear.

## Examples

**Finding best achievable gear set**

If want to find the best possible gear from all the possible gear then in theory we would mark all gear/enchants/gems as available and run the optimizer. Even though the optimizer does not look at all options, just looking at each item once would be quite impossible in this case due to sheer number of possible gemming variants.

Due to this we have to restrict our options. Instead of marking all gems as available look through the charts and select the first few gems of each color. Do the same for enchants. Since we want to consider all gemmings and enchants we mark items with green diamonds. Again mark only the best few options in each slot and make sure to include any special items such as items that affect set bonuses. Based on how fast the optimizer works you can then expand the search with more options. Make sure to run the optimizer several times since just running it once is not guaranteed to give you the best answer.

**Enchanting and gemming your gear**

This problem is very similar to the above except in this case we only consider gear that we have. Select gems and enchants that you have access to and then mark the items that you currently have with green diamonds. Running the optimizer will give you a character setup using this gear and you can use the suggested enchanting and gemming to modify your gear.

**Finding gear sets for different situations**

Main difference in this case is that we generally do not change gems/enchants on our items between fights, so in this case we want to find the best solutions using very specific items. Instead of marking items with green diamonds we mark just the specific gemmings we have with a blue diamond and restricting enchants on that item to just the enchant that your item currently has. If you have more of the same item you can specify this by marking several enchants as available or marking several gemmings with blue diamond. Selecting gems and enchants in this case is not important since all the gemmings/enchants are already specified for each item.

Note that you can always just mark items in this way and when you want to answer the question of how to improve your gemmings/enchants you can just use the gemming/enchanting override option in the optimizer.

**Finding gear upgrades**

This is achieved by using the "Build Upgrade List" command instead of Optimize. Basically it will run optimize for each possible item using the available gems and enchants. One difference is that it will force use of that item in that slot so in some extreme cases it might even be able to find better solutions than normal optimize would.

When all items are evaluated you will be presented with a new window with items sorted by their upgrade value. This is the best optimized value including a specific item minus current value. This means that if an item that is already marked as available shows in the upgrade chart it means that your current setup is not optimal and you can use that information to improve your gemmings and enchants.

One difference in this chart is that when mousing over items you will get additional information about how the upgrade is achieved. You will see the enchant that was used and also which items are used in the other slots to achieve the improvement. You will also get a new option in the context menu to equip all the items that are used to achieve that upgrade.

In addition to looking for all upgrades you can also evaluate upgrade value of a particular item. To do this select Evaluate Upgrade from the context menu for the item. This will run build upgrade list using your last optimizer settings, but only for that item. This way you can use it as a quick way to find the best gemming/enchanting for that particular item. Note that the upgrade list will be empty if the item cannot improve the current gear setup.