﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Rawr
{
    public interface ICharacterCalculationOptions
    {
        Character Character { get; set; }
    }
}
