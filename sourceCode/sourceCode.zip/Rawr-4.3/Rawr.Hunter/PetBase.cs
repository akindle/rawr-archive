﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace Rawr.Hunter
{
    public class PetBase
    {
        public StatsHunter Stats { get; private set; }
    }
}