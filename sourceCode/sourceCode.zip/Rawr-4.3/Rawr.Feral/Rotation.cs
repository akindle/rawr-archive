﻿using System;
using System.Collections.Generic;
using System.Text;
using Rawr.Base.Algorithms;

namespace Rawr.Feral
{
    public class Rotation
    {
        public const uint MIN_GCD_MS = 1500;
        
    }
}