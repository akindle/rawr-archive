﻿
local L = LibStub("AceLocale-3.0"):NewLocale("Rawr", "zhTW", false);
if not L then return end

--@localization(locale="zhTW", format="lua_additive_table", handle-subnamespaces="concat", handle-unlocalized="english")@
