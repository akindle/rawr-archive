namespace Rawr.Server
{
	partial class RawrDBDataContext
	{
	}
}
