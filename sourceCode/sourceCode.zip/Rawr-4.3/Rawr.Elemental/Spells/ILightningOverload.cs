﻿namespace Rawr.Elemental.Spells
{
    public interface ILightningOverload
    {
        float LOChance(float masteryRating);
        float LightningOverloadDamage();

    }
}
